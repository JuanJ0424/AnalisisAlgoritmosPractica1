#include <stdio.h>
#include <stdlib.h>
#include "tiempo.h"

void shell_sort(int *numbers, int n);

int main(int argc, char const *argv[]) {
    double utime0, stime0, wtime0,utime1, stime1, wtime1; //Variables para medición de tiempos
    if(argc>=2){

        int size = atoi(argv[1]);
        int *numbers = (int *)malloc(sizeof(int)*size);

        for(int i=0;i<size;++i){
            scanf("%d",&numbers[i]);
        }

        uswtime(&utime0, &stime0, &wtime0);
        shell_sort(numbers,size);
        uswtime(&utime1, &stime1, &wtime1);

        //Cálculo del tiempo de ejecución del programa
        printf("\n");
        printf("real (Tiempo total)  %.10f s\n",  wtime1 - wtime0);
        printf("user (Tiempo de procesamiento en CPU) %.10f s\n",  utime1 - utime0);
        printf("sys (Tiempo en acciónes de E/S)  %.10f s\n",  stime1 - stime0);
        printf("CPU/Wall   %.10f %% \n",100.0 * (utime1 - utime0 + stime1 - stime0) / (wtime1 - wtime0));
        printf("\n");
        
        //Mostrar los tiempos en formato exponecial
        printf("\n");
        printf("real (Tiempo total)  %.10e s\n",  wtime1 - wtime0);
        printf("user (Tiempo de procesamiento en CPU) %.10e s\n",  utime1 - utime0);
        printf("sys (Tiempo en acciónes de E/S)  %.10e s\n",  stime1 - stime0);
        printf("CPU/Wall   %.10f %% \n",100.0 * (utime1 - utime0 + stime1 - stime0) / (wtime1 - wtime0));
        printf("\n");
            
    }else{
        printf("Argumentos insuficientes\n");
    }
    return 0;
}

// Shell sort
void shell_sort(int *numbers,int n){
    int k =  n/2;
    int v;
    int j;
    while(k>=1){
        for(int i=k;i<n;++i){
            v = numbers[i];
            j = i - k;
            // Comparamos con un elemento anterior, a k distancia hasta que el comparador sea el menor en todos sus saltos
            while(j>=0 && numbers[j] > v){
                numbers[j+k] = numbers[j];
                j-=k;
            } 
            numbers[j+k]=v;
        }
        // Se reduce a la mitad la distancia del salto
        k/=2;
    }
    // for(int i=0;i<n;i++){
    //     printf("%d\n",numbers[i]);    
    // }
}