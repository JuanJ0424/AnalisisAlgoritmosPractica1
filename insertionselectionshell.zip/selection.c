#include <stdio.h>
#include <stdlib.h>
#include "tiempo.h"
void selection_sort(int *numbers,int numbers);

int main(int argc, char const *argv[]) {
    
    if(argc>=2){
        double utime0, stime0, wtime0,utime1, stime1, wtime1; //Variables para medición de tiempos
        int size = atoi(argv[1]);
        int *numbers = (int *)malloc(sizeof(int)*size);

        for(int i=0;i<size;++i){
            scanf("%d",&numbers[i]);
        }

        uswtime(&utime0, &stime0, &wtime0);
        selection_sort(numbers,size);
        uswtime(&utime1, &stime1, &wtime1);

            //Cálculo del tiempo de ejecución del programa
            printf("\n");
            printf("real (Tiempo total)  %.10f s\n",  wtime1 - wtime0);
            printf("user (Tiempo de procesamiento en CPU) %.10f s\n",  utime1 - utime0);
            printf("sys (Tiempo en acciónes de E/S)  %.10f s\n",  stime1 - stime0);
            printf("CPU/Wall   %.10f %% \n",100.0 * (utime1 - utime0 + stime1 - stime0) / (wtime1 - wtime0));
            printf("\n");
            
            //Mostrar los tiempos en formato exponecial
            printf("\n");
            printf("real (Tiempo total)  %.10e s\n",  wtime1 - wtime0);
            printf("user (Tiempo de procesamiento en CPU) %.10e s\n",  utime1 - utime0);
            printf("sys (Tiempo en acciónes de E/S)  %.10e s\n",  stime1 - stime0);
            printf("CPU/Wall   %.10f %% \n",100.0 * (utime1 - utime0 + stime1 - stime0) / (wtime1 - wtime0));
            printf("\n");
            
    }else{
        printf("Argumentos insuficientes\n");
    }
    
    return 0;
}

void selection_sort(int *numbers,int size) {
    
    int min;

    for (int k = 0; k <= size-1; ++k) {
        min = k;
        for (int i = k+1; i <= size-1; ++i){
            if(numbers[i]<numbers[min]){
                min=i;
            }
        }
        if (min!=k){
            int Temp = numbers[min];
            numbers[min]=numbers[k];
            numbers[k] = Temp;
        }
        //printf("%d\n",numbers[k]);
    }
    // for (int i = 0; i < size; ++i) {
    //     printf("%d\n",numbers[i]);    
    // }
}
